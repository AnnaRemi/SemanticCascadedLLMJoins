# What `intro.tex` (and `section31.tex`) must change to match the new `main.tex`

`main.tex` pulls in `\input{intro}` and `\input{section31}`. Those two files were **missing from the Overleaf project**
(compile error `File 'intro.tex' not found`), so reconstructed versions were added next to `main.tex`: `intro.tex` (the old
introduction with the claims below already updated and the cross-references mapped to the current labels) and `section31.tex`
(the old running example wrapped in an `example` environment). If you have your own originals, use them and apply the table
below to your introduction instead.

## Claims to replace (from the old introduction)

| Old claim | Why it no longer holds | New numbers (10q x 10 reps, Gemma 4 e2b / 26b) |
|---|---|---|
| "cascading the batched-join baseline gives the best cost-quality trade-off of the four methods" | On IMDb, SUQL is on the Pareto front too and is 4% cheaper; on Amazon SUQL has the higher F1 | IMDb: CasTrummer F1 0.713 vs SUQL 0.501 at +3.7% cost; Amazon: CasTrummer F1 0.673 vs SUQL 0.779 at -20% cost |
| "2.03x faster and uses 10x fewer LLM calls than its own uncascaded baseline" | Wall time is the same; calls are 28% (IMDb) / 8% (Amazon) lower than Trummer | CasTrummer vs Trummer: calls 7.56 vs 10.5 (-28.0%), wall 25.65 s vs 25.39 s (+1.0%) |
| "+70% F1" over its own baseline | The gain is larger on IMDb and smaller on Amazon | IMDb +109.7% (0.340 -> 0.713), Amazon +45.1% (0.464 -> 0.673) |
| "the only method that does not collapse in quality on the hardest questions" | Not re-evaluated with the fixed pipeline; CasTrummer also scores F1 0 on one Amazon question (q9) | drop the sentence, or re-check per question |
| any statement that CasSuql trades time for quality ("+2.7% F1 for 7.99x time") | Quality parity, about 1.9x time | CasSuql vs SUQL: F1 -0.2% (IMDb) / +2.1% (Amazon); wall +89.9% / +82.8%; calls +94.9% / +86.2% |
| Q* = 0.9 / "narrowest band with both Beta bounds" | Q* = 0.9 cannot be certified with 20 labels; the calibration is now stratified | Q* = 0.8, alpha = 0.9, |C| = 20, 4 strata (see Sec. 4.4 of `main.tex`) |
| ground truth "labeled manually" | Ground truth is deterministic: structured predicate AND hand-authored regular-expression patterns over the review text, no LLM judge (`imdb/benchmarks/build_catalog.py`, `amazon/benchmarks/build_local_catalog.py`) | |

## Suggested replacement for the final claim paragraph of the introduction

> We evaluate all four resulting methods -- the two baselines and their cascaded variants -- on ten held-out questions over a $\sim$25,000-row IMDb corpus of movies and reviews, and check whether the findings hold on a second, structurally different domain (Amazon Fashion reviews). The calibrated cascades behave as designed: they never lose recall relative to the expensive model they escalate to. In our setting, however, they do not save time. \textsc{CasSuql} reproduces the F1 of \textsc{Suql} at 1.8 to 1.9 times its wall-clock time, because a cheap call is nearly as slow as an expensive one and a 20-row calibration set certifies the cheap stage on only a few rows. \textsc{CasTrummer} issues 81--83\% fewer LLM calls than \textsc{Suql} and improves the F1 of \textsc{Trummer} by 110\% on IMDb and 45\% on Amazon Fashion at a similar wall-clock time, but an ablation without the cheap stage shows that this gain comes from structural filtering and batched expensive verification, not from cascading. The rest of the paper details the two baselines, the cascade architecture and its calibration, the conditions under which a cascade can pay off, and the experiments supporting these findings.

If the introduction also has a contributions list, add: (i) a calibration that certifies recall and precision of the cheap stage from a score-stratified sample (Sec. 4.4) and (ii) a cost model, $t_c/t_e < d$, that predicts when a cascade is faster than its baseline (Sec. 4.3).

## `section31.tex`

The running example (movies `tt0100`--`tt0103`) contains no experimental numbers, so it needs no change. `main.tex` still
refers to its label `ex:running`.

## Other things to check on Overleaf

- `refs.bib` in this repository is older than the Overleaf one: it lacks `chen2023frugalgpt`, `garcia2008database`,
  `gelman2013bayesian`, `kotte2026ucci`, `ramakrishnan2003database`, `zeighami2026bargain`, `zhang2025scaledoc`,
  all cited by the original text. No citation was added.
- New figure: `figs/pareto/cost_f1_pareto_both_datasets.png` (regenerate from `paper_outputs/` if needed).
- One Amazon question (q9) gives F1 = 0 for CasTrummer and for the variant without a cheap stage; the cause has not been analysed.
